# YumeYuka Starry Oath
#
# Copyright (c) 2025 YumeYuka
#
# Permission is hereby granted to anyone to freely copy, distribute, modify, merge, sell, publish, sublicense, or otherwise use this work, subject to the following conditions:
#
# 1.  All copies or substantial portions of this work must include the name "YumeYuka" as the original author.
# 2.  All risks and liabilities arising from the use of this work shall be borne solely by the user.
#
# The author YumeYuka provides this work "AS IS", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, and noninfringement. This work may function, or it may fail completely; no intermediate state exists.
#
#             Terms and Conditions
#
# 0.  The author shall not be liable for any claim, damages, or other liability arising from the use of this work, whether in an action of contract, tort, or otherwise.
#
# Beneath the starry sky, freedom is yours.

baseDir="$(dirname "$(readlink -f "$0")")"
[ -f "$baseDir/nga-utils.sh" ] && . "$baseDir/nga-utils.sh" || exit

until_unlock 30

nohup_bin "$baseDir/Yume-Yunyun"
